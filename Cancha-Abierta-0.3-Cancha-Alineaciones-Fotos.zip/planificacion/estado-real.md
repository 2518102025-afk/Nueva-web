# Estado de Cancha Abierta - versión de datos reales

**Actualización de planificación: 1 de noviembre de 2026**

- Frontend estático desplegable en GitHub Pages.
- 19 competiciones y temporadas identificadas.
- Premier y LaLiga 2026/27: clubes oficiales completos.
- El Salvador Apertura 2026: 12 clubes verificados.
- UCL, UEL y UECL: clubes y encuentros de noviembre documentados por UEFA.
- Otras competiciones: clubes de fuentes oficiales o partidos contrastados; algunas listas son parciales.
- Archivo histórico ELNINE para 01/11/2026.
- Consulta ESPN directa desde cliente es solo experimental, no oficial. No garantiza resultados continuos ni licencia de uso comercial.
- Favoritos guardados en navegador, diseño adaptable y temas claro/oscuro.
- Administración real de noticias y fichajes aún pendiente de backend.

**No anunciar que Cancha Abierta cuenta con marcador en vivo permanente.** Solo podrá mostrarlos mientras las consultas externas respondan y los datos sean válidos.
