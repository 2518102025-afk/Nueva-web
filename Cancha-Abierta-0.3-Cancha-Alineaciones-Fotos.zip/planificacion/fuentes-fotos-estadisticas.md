# Fotos, alineaciones y estadísticas: versión 0.3

Fecha de revisión: 1 de noviembre de 2026.

## Qué implementamos

1. Galería de cuatro futbolistas reales (Messi, Mbappé, Lamine Yamal y Haaland) en Buscar. Cada ficha enseña créditos, enlace al archivo original y licencia de Wikimedia Commons. Las imágenes se sirven desde Commons y necesitan conexión.
2. Canchas para los dos equipos en la pestaña Alineaciones. Para dibujar una formación real de un encuentro, la fuente debe aportar los once titulares, la formación táctica y la posición del jugador en dicha formación. Si falta alguno de estos elementos, no inventamos alineaciones. Hay un esquema 4-3-3 claramente rotulado como demostración.
3. Cada ficha de jugador y equipo ofrece un enlace para buscar información en Transfermarkt (sitio externo). La web no automatiza ninguna extracción de ese portal.
4. Campo preparado para estadísticas con fuente autorizada por temporada, pero sin números añadidos sin verificación ni permiso. Aparecen guiones como valor no disponible.

## Limitaciones y licencias

- Transfermarkt, términos de uso: https://www.transfermarkt.us/intern/anb (cláusula sobre scraping y automatización).
- Wikimedia Commons, reutilización y atribución: https://commons.wikimedia.org/wiki/Commons:Reusing_content_outside_Wikimedia
- Fuente experimental de alineaciones: ESPN sitio público, sin contrato de redistribución. Ver descripción del proyecto en README.
- La ubicación en cancha es un dibujo táctico de la formación inicial. No estima ubicación GPS/posicional real durante el partido.
- Los datos de jugadores y estadísticas de clubes no se atribuyen a una temporada diferente de la indicada.

## Para estadísticas reales de la temporada

Requerimos API o archivo exportado con autorización para publicar los datos y con esta información mínima: jugador, competición, temporada, partidos, goles, asistencias, minutos, fecha y URL de fuente. El almacenamiento de esta información debe respetar las licencias.
